import pygame

pygame.init()

WIDTH = 800
HEIGHT = 800
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Primitive Paint")

class Rect:
    def __init__(self, x, y, w, h, color):
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.color = color

    def draw(self):
        pygame.draw.rect(screen, self.color, (self.x, self.y, self.w, self.h))

class Circle:
    def __init__(self, x, y, radius, color):
        self.x = x
        self.y = y
        self.radius = radius
        self.color = color

    def draw(self):
        pygame.draw.circle(screen, self.color, (self.x, self.y), self.radius)

palette = [
    "#000000",
    "#FFFFFF",
    "#FF0000",
    "#FF8800",
    "#FFFF00",
    "#00CC44",
    "#00CCFF",
    "#0066FF",
    "#8800FF",
    "#FF00AA",
    "#8B4513",
    "#808080"
]

buttons = []

for i, color in enumerate(palette):
    buttons.append(Rect(20 + i * 45, 15, 35, 35, color))

clear_button = Rect(580, 15, 80, 35, "#444444")
eraser_button = Rect(670, 15, 80, 35, "#AAAAAA")

canvas = pygame.Surface((WIDTH, HEIGHT))
canvas.fill("#FFFFFF")

brush_color = "#000000"
brush_size = 10
drawing = False
eraser = False

running = True

while running:
    screen.fill("#202629")

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.MOUSEBUTTONDOWN:
            mx, my = pygame.mouse.get_pos()

            for i, button in enumerate(buttons):
                if pygame.Rect(
                    button.x,
                    button.y,
                    button.w,
                    button.h
                ).collidepoint(mx, my):
                    brush_color = palette[i]
                    eraser = False

            if pygame.Rect(
                clear_button.x,
                clear_button.y,
                clear_button.w,
                clear_button.h
            ).collidepoint(mx, my):
                canvas.fill("#FFFFFF")

            if pygame.Rect(
                eraser_button.x,
                eraser_button.y,
                eraser_button.w,
                eraser_button.h
            ).collidepoint(mx, my):
                eraser = not eraser

            if my > 70:
                drawing = True

        if event.type == pygame.MOUSEBUTTONUP:
            drawing = False

        if event.type == pygame.MOUSEMOTION and drawing:
            mx, my = pygame.mouse.get_pos()

            if my > 70:
                color = "#FFFFFF" if eraser else brush_color

                brush = Circle(
                    mx,
                    my,
                    brush_size,
                    color
                )

                brush.draw()

                pygame.draw.circle(
                    canvas,
                    color,
                    (mx, my),
                    brush_size
                )

        if event.type == pygame.MOUSEWHEEL:
            brush_size += event.y
            brush_size = max(1, min(50, brush_size))

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_c:
                canvas.fill("#FFFFFF")

            if event.key == pygame.K_e:
                eraser = not eraser

            if event.key == pygame.K_LEFTBRACKET:
                brush_size = max(1, brush_size - 1)

            if event.key == pygame.K_RIGHTBRACKET:
                brush_size = min(50, brush_size + 1)

    screen.blit(canvas, (0, 0))

    pygame.draw.rect(screen, "#202629", (0, 0, WIDTH, 70))

    for button in buttons:
        button.draw()

    clear_button.draw()
    eraser_button.draw()

    font = pygame.font.SysFont(None, 22)

    screen.blit(
        font.render("CLEAR", True, "#FFFFFF"),
        (597, 24)
    )

    screen.blit(
        font.render("ERASE", True, "#000000"),
        (687, 24)
    )

    screen.blit(
        font.render(
            "Size: " + str(brush_size),
            True,
            "#FFFFFF"
        ),
        (20, 765)
    )

    pygame.display.flip()

pygame.quit()