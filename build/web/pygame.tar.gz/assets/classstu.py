import pygame

pygame.init()

WIDTH = 800
HEIGHT = 800
screen = pygame.display.set_mode((WIDTH, HEIGHT))

class Rect:
    def __init__(self, x, y, w, h, color):
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.color = color

    def draw(self):
        pygame.draw.rect(screen, self.color, (self.x, self.y, self.w, self.h))

board = []

for row in range(8):
    for col in range(8):
        if (row + col) % 2 == 0:
            color = "#FFFFFF"
        else:
            color = "#000000"
        board.append(Rect(col * 100, row * 100, 100, 100, color))

running = True

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    for square in board:
        square.draw()

    pygame.display.flip()

pygame.quit()