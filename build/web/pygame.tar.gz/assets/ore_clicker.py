import pygame, random

pygame.init()
W, H = 1000, 640
screen = pygame.display.set_mode((W, H))
pygame.display.set_caption("Earth Inc - Ore Clicker")
clock = pygame.time.Clock()
font = pygame.font.SysFont("consolas", 16)
small = pygame.font.SysFont("consolas", 14)
mid = pygame.font.SysFont("consolas", 22, True)
big = pygame.font.SysFont("consolas", 34, True)

LEVELS = [
    ("Poor", 0, 0),
    ("Medium", 3, 15),
    ("Rich", 8, 50),
    ("Strong", 15, 120),
    ("Elite", 25, 250),
    ("Mythic", 40, 500),
]

RARITY = {
    "Common": (60, (200, 200, 200)),
    "Uncommon": (25, (110, 220, 110)),
    "Rare": (10, (90, 160, 255)),
    "Epic": (4, (190, 100, 255)),
    "Legendary": (1, (255, 170, 40)),
}

ORE_DATA = [
    ("Coal", "ores/01_coal_ore.png", 5, 1, 0, "Common"),
    ("Iron", "ores/02_iron_ore.png", 7, 2, 0, "Common"),
    ("Copper", "ores/03_copper_ore.png", 10, 3, 0, "Common"),
    ("Tin", "ores/04_tin_ore.png", 14, 6, 0, "Common"),
    ("Lead", "ores/05_lead_ore.png", 18, 9, 0, "Uncommon"),
    ("Zinc", "ores/06_zinc_ore.png", 24, 12, 0, "Uncommon"),
    ("Nickel", "ores/07_nickel_ore.png", 29, 15, 0, "Uncommon"),
    ("Silver", "ores/08_silver_ore.png", 35, 19, 0, "Rare"),
    ("Gold", "ores/09_gold_ore.png", 41, 23, 0, "Rare"),
    ("Platinum", "ores/10_platinum_ore.png", 48, 28, 0, "Epic"),
    ("Titanium", "ores/11_titanium_ore.png", 55, 32, 1, "Common"),
    ("Bauxite", "ores/12_bauxite_ore.png", 62, 37, 1, "Common"),
    ("Cobalt", "ores/13_cobalt_ore.png", 69, 42, 1, "Common"),
    ("Tungsten", "ores/14_tungsten_ore.png", 77, 47, 1, "Common"),
    ("Uranium", "ores/15_uranium_ore.png", 85, 53, 1, "Uncommon"),
    ("Lithium", "ores/16_lithium_ore.png", 93, 59, 1, "Uncommon"),
    ("Magnesium", "ores/17_magnesium_ore.png", 102, 65, 1, "Uncommon"),
    ("Chromium", "ores/18_chromium_ore.png", 110, 71, 1, "Rare"),
    ("Manganese", "ores/19_manganese_ore.png", 119, 77, 1, "Rare"),
    ("Cinnabar", "ores/20_cinnabar_ore.png", 128, 83, 1, "Epic"),
    ("Sulfur", "ores/21_sulfur_ore.png", 137, 90, 2, "Common"),
    ("Rock Salt", "ores/22_rock_salt_ore.png", 146, 97, 2, "Common"),
    ("Quartz", "ores/23_quartz_ore.png", 156, 104, 2, "Common"),
    ("Diamond", "ores/24_diamond_ore.png", 166, 111, 2, "Common"),
    ("Emerald", "ores/25_emerald_ore.png", 176, 118, 2, "Uncommon"),
    ("Ruby", "ores/26_ruby_ore.png", 186, 126, 2, "Uncommon"),
    ("Sapphire", "ores/27_sapphire_ore.png", 196, 133, 2, "Uncommon"),
    ("Amethyst", "ores/28_amethyst_ore.png", 206, 141, 2, "Rare"),
    ("Topaz", "ores/29_topaz_ore.png", 217, 149, 2, "Rare"),
    ("Opal", "ores/30_opal_ore.png", 228, 157, 2, "Epic"),
    ("Garnet", "ores/31_garnet_ore.png", 238, 165, 3, "Common"),
    ("Jade", "ores/32_jade_ore.png", 249, 173, 3, "Common"),
    ("Obsidian", "ores/33_obsidian_ore.png", 260, 182, 3, "Common"),
    ("Onyx", "ores/34_onyx_ore.png", 272, 190, 3, "Common"),
    ("Peridot", "ores/35_peridot_ore.png", 283, 199, 3, "Uncommon"),
    ("Aquamarine", "ores/36_aquamarine_ore.png", 295, 208, 3, "Uncommon"),
    ("Turquoise", "ores/37_turquoise_ore.png", 306, 217, 3, "Uncommon"),
    ("Moonstone", "ores/38_moonstone_ore.png", 318, 226, 3, "Rare"),
    ("Sunstone", "ores/39_sunstone_ore.png", 330, 235, 3, "Rare"),
    ("Lapis", "ores/40_lapis_ore.png", 342, 244, 3, "Epic"),
    ("Malachite", "ores/41_malachite_ore.png", 354, 253, 4, "Common"),
    ("Azurite", "ores/42_azurite_ore.png", 367, 263, 4, "Common"),
    ("Graphite", "ores/43_graphite_ore.png", 379, 273, 4, "Common"),
    ("Flint", "ores/44_flint_ore.png", 392, 282, 4, "Common"),
    ("Amber", "ores/45_amber_ore.png", 404, 292, 4, "Uncommon"),
    ("Fluorite", "ores/46_fluorite_ore.png", 417, 302, 4, "Uncommon"),
    ("Cryolite", "ores/47_cryolite_ore.png", 430, 312, 4, "Uncommon"),
    ("Mythril", "ores/48_mythril_ore.png", 443, 323, 4, "Rare"),
    ("Adamantite", "ores/49_adamantite_ore.png", 456, 333, 4, "Rare"),
    ("Orichalcum", "ores/50_orichalcum_ore.png", 469, 344, 4, "Epic"),
    ("Starmetal", "ores/51_starmetal_ore.png", 483, 354, 5, "Common"),
    ("Voidstone", "ores/52_voidstone_ore.png", 496, 365, 5, "Common"),
    ("Ember Crystal", "ores/53_ember_crystal_ore.png", 510, 375, 5, "Common"),
    ("Frost Crystal", "ores/54_frost_crystal_ore.png", 523, 386, 5, "Common"),
    ("Luminite", "ores/55_luminite_ore.png", 537, 397, 5, "Uncommon"),
    ("Plasma Ore", "ores/56_plasma_ore_ore.png", 551, 408, 5, "Uncommon"),
    ("Aether Shard", "ores/57_aether_shard_ore.png", 565, 420, 5, "Uncommon"),
    ("Bloodstone", "ores/58_bloodstone_ore.png", 579, 431, 5, "Rare"),
    ("Meteorite", "ores/59_meteorite_ore.png", 593, 442, 5, "Rare"),
    ("Celestine", "ores/60_celestine_ore.png", 607, 454, 5, "Legendary"),
]

ores = []
for name, path, health, coin, lvl, rarity in ORE_DATA:
    img = pygame.image.load(path).convert_alpha()
    dark = pygame.transform.scale(img, (40, 40))
    icon = dark.copy()
    dark.fill((60, 60, 60, 255), special_flags=pygame.BLEND_RGBA_MULT)
    ores.append({
        "name": name,
        "icon": icon,
        "dark": dark,
        "big": pygame.transform.scale(img, (256, 256)),
        "color": pygame.transform.average_color(img),
        "health": health,
        "coin": coin,
        "level": lvl,
        "rarity": rarity,
        "found": 0,
    })

upgrades = [
    {"name": "Pickaxe", "desc": "+1 damage per click", "cost": 10, "lvl": 0, "max": 99},
    {"name": "Auto Miner", "desc": "+1 damage per second", "cost": 50, "lvl": 0, "max": 99},
    {"name": "Gold Touch", "desc": "+10% coins per ore", "cost": 100, "lvl": 0, "max": 99},
    {"name": "Lucky Strike", "desc": "+5% chance of double hit", "cost": 150, "lvl": 0, "max": 10},
]

coins = 0
collected = 0
level = 0
cur = 0
hp = 1
scroll = 0
shake = 0
auto_t = 0
banner = ["", 0]
particles = []
popups = []
ore_rect = pygame.Rect(0, 0, 256, 256)
ore_rect.center = (500, 310)
LIST_TOP, ROW = 44, 64


def bought():
    return sum(u["lvl"] for u in upgrades)


def cost(u):
    return int(u["cost"] * 1.6 ** u["lvl"])


def spawn():
    global cur, hp
    weights = []
    for o in ores:
        if o["level"] > level:
            weights.append(0)
        else:
            weights.append(RARITY[o["rarity"]][0] * (3 if o["level"] == level else 1))
    cur = random.choices(range(len(ores)), weights)[0]
    hp = ores[cur]["health"]


def check_level():
    global level, banner
    while level + 1 < len(LEVELS) and bought() >= LEVELS[level + 1][1] and collected >= LEVELS[level + 1][2]:
        level += 1
        banner = ["LEVEL UP: " + LEVELS[level][0], 2.5]


def reward(o):
    return max(1, round(o["coin"] * (1 + 0.1 * upgrades[2]["lvl"])))


def hit(dmg):
    global hp, coins, shake, collected
    o = ores[cur]
    hp -= dmg
    shake = 0.15
    for _ in range(6):
        particles.append([ore_rect.centerx + random.randint(-60, 60), ore_rect.centery + random.randint(-60, 60),
                          random.uniform(-120, 120), random.uniform(-220, -40), 0.6, o["color"]])
    if hp <= 0:
        gain = reward(o)
        coins += gain
        collected += 1
        o["found"] += 1
        popups.append(["+%d" % gain, ore_rect.centerx - 20, ore_rect.top, 1.0])
        for _ in range(24):
            particles.append([ore_rect.centerx, ore_rect.centery, random.uniform(-300, 300),
                              random.uniform(-350, 50), 0.9, RARITY[o["rarity"]][1]])
        check_level()
        spawn()


def click_dmg():
    d = 1 + upgrades[0]["lvl"]
    if random.random() < 0.05 * upgrades[3]["lvl"]:
        d *= 2
    return d


def shop_rect(i):
    return pygame.Rect(710, 60 + i * 96, 280, 86)


def txt(f, s, c, pos):
    screen.blit(f.render(s, True, c), pos)


def center(f, s, c, y):
    screen.blit(f.render(s, True, c), (500 - f.size(s)[0] // 2, y))


spawn()
running = True
while running:
    dt = clock.tick(60) / 1000
    for e in pygame.event.get():
        if e.type == pygame.QUIT:
            running = False
        elif e.type == pygame.MOUSEWHEEL:
            scroll -= e.y * 40
        elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            p = e.pos
            if ore_rect.collidepoint(p):
                hit(click_dmg())
            elif p[0] > 700:
                for i, u in enumerate(upgrades):
                    if shop_rect(i).collidepoint(p) and u["lvl"] < u["max"] and coins >= cost(u):
                        coins -= cost(u)
                        u["lvl"] += 1
                        check_level()
    scroll = max(0, min(scroll, len(ores) * ROW - (H - LIST_TOP)))

    if upgrades[1]["lvl"]:
        auto_t += dt
        if auto_t >= 1:
            auto_t -= 1
            hit(upgrades[1]["lvl"])
    shake = max(0, shake - dt)
    banner[1] = max(0, banner[1] - dt)
    for p in particles:
        p[0] += p[2] * dt
        p[1] += p[3] * dt
        p[3] += 700 * dt
        p[4] -= dt
    particles = [p for p in particles if p[4] > 0]
    for p in popups:
        p[2] -= 50 * dt
        p[3] -= dt
    popups = [p for p in popups if p[3] > 0]

    screen.fill((30, 26, 38))

    pygame.draw.rect(screen, (22, 18, 30), (0, 0, 300, H))
    old = screen.get_clip()
    screen.set_clip(pygame.Rect(0, LIST_TOP, 300, H - LIST_TOP))
    for i, o in enumerate(ores):
        r = pygame.Rect(6, LIST_TOP + i * ROW - scroll, 288, ROW - 4)
        if r.bottom < LIST_TOP or r.top > H:
            continue
        locked = o["level"] > level
        pygame.draw.rect(screen, (70, 60, 100) if i == cur else (40, 34, 54), r, border_radius=6)
        screen.blit(o["dark"] if locked else o["icon"], (r.x + 6, r.y + 10))
        txt(font, o["name"], (110, 110, 120) if locked else (240, 240, 250), (r.x + 56, r.y + 4))
        if locked:
            txt(small, "Locked: " + LEVELS[o["level"]][0], (140, 120, 120), (r.x + 56, r.y + 24))
        else:
            txt(small, "%s  %s" % (LEVELS[o["level"]][0], o["rarity"]), RARITY[o["rarity"]][1], (r.x + 56, r.y + 24))
            txt(small, "HP %d  $%d" % (o["health"], o["coin"]), (200, 190, 120), (r.x + 56, r.y + 41))
            if o["found"]:
                t = "x%d" % o["found"]
                txt(small, t, (255, 255, 255), (r.right - small.size(t)[0] - 8, r.y + 4))
    screen.set_clip(old)
    pygame.draw.rect(screen, (22, 18, 30), (0, 0, 300, LIST_TOP))
    txt(mid, "ORES", (255, 255, 255), (12, 10))

    o = ores[cur]
    t = "$ %d" % coins
    center(big, t, (255, 215, 80), 10)
    center(mid, "Level: " + LEVELS[level][0], (255, 255, 255), 52)
    if level + 1 < len(LEVELS):
        n = LEVELS[level + 1]
        t = "Next: %s   Upgrades %d/%d   Ores %d/%d" % (n[0], bought(), n[1], collected, n[2])
    else:
        t = "Max level   Ores collected %d" % collected
    center(small, t, (170, 170, 190), 82)
    center(mid, o["name"], (255, 255, 255), 112)
    center(font, o["rarity"], RARITY[o["rarity"]][1], 140)
    s = 1 - shake * 0.8
    img = pygame.transform.scale(o["big"], (int(256 * s), int(256 * s)))
    screen.blit(img, img.get_rect(center=ore_rect.center))
    bar = pygame.Rect(0, 0, 300, 20)
    bar.center = (500, 480)
    pygame.draw.rect(screen, (60, 30, 30), bar, border_radius=6)
    fill = bar.copy()
    fill.width = int(bar.width * max(0, hp) / o["health"])
    pygame.draw.rect(screen, (220, 70, 70), fill, border_radius=6)
    pygame.draw.rect(screen, (255, 255, 255), bar, 2, border_radius=6)
    center(font, "%d / %d" % (max(0, hp), o["health"]), (255, 255, 255), 508)
    center(font, "Reward: %d coins" % reward(o), (200, 190, 120), 532)
    center(font, "Damage per click: %d   Auto: %d/s" % (1 + upgrades[0]["lvl"], upgrades[1]["lvl"]), (170, 170, 190), 560)

    for p in particles:
        pygame.draw.rect(screen, p[5], (int(p[0]), int(p[1]), 6, 6))
    for p in popups:
        txt(mid, p[0], (255, 230, 100), (p[1], p[2]))
    if banner[1] > 0:
        label = big.render(banner[0], True, (255, 230, 100))
        shadow = big.render(banner[0], True, (20, 14, 30))
        pos = (500 - label.get_width() // 2, 250)
        screen.blit(shadow, (pos[0] + 3, pos[1] + 3))
        screen.blit(label, pos)

    pygame.draw.rect(screen, (22, 18, 30), (700, 0, 300, H))
    txt(mid, "UPGRADE SHOP", (255, 255, 255), (720, 14))
    for i, u in enumerate(upgrades):
        r = shop_rect(i)
        maxed = u["lvl"] >= u["max"]
        ok = not maxed and coins >= cost(u)
        pygame.draw.rect(screen, (50, 110, 60) if ok else (44, 38, 58), r, border_radius=8)
        pygame.draw.rect(screen, (120, 200, 130) if ok else (80, 72, 100), r, 2, border_radius=8)
        txt(font, "%s  Lv %d" % (u["name"], u["lvl"]), (255, 255, 255), (r.x + 10, r.y + 8))
        txt(font, u["desc"], (190, 190, 210), (r.x + 10, r.y + 32))
        txt(font, "MAX" if maxed else "Cost: %d" % cost(u), (255, 215, 80), (r.x + 10, r.y + 58))

    pygame.display.flip()

pygame.quit()
