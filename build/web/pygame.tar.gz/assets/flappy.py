import pygame
import random
import os
import pickle
import sys

pygame.init()

WIDTH = 864
HEIGHT = 768
running = True
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()
game = True

base_path = os.path.dirname(os.path.abspath(__file__))

bg = pygame.image.load(os.path.join(base_path, "sky.png"))
frame1 = pygame.image.load(os.path.join(base_path, "flappy1.png"))
frame2 = pygame.image.load(os.path.join(base_path, "flappy2.png"))
frame3 = pygame.image.load(os.path.join(base_path, "flappy3.png"))
frame123 = [frame1, frame2, frame3]
restart = pygame.image.load(os.path.join(base_path, "restart.png"))
ground = pygame.image.load(os.path.join(base_path, "ground.png"))
ground = pygame.transform.scale(ground, (1600, 100))
pipe_img = pygame.image.load(os.path.join(base_path, "pipe.png"))

ground_x = 0
restart_rect = restart.get_rect(center=(WIDTH // 2, HEIGHT // 2 + 80))

font_path = pygame.font.match_font("consolas") or pygame.font.match_font("Courier New")
font = pygame.font.Font(font_path, 36)
font_large = pygame.font.Font(font_path, 54)

score = 0
high_score = 0
AI_FILE = os.path.join(base_path, "flappy_population.nyp")
POPULATION_SIZE = 30
AI_ENABLED = "--AI" in sys.argv
jump_cooldown = 0
ai_start_time = pygame.time.get_ticks()

def load_population():
    try:
        with open(AI_FILE, "rb") as file:
            saved = pickle.load(file)
            if (
                isinstance(saved, list)
                and len(saved) == POPULATION_SIZE
                and all(
                    isinstance(genome, list)
                    and len(genome) == 6
                    and all(isinstance(value, (int, float)) for value in genome)
                    for genome in saved
                )
            ):
                return saved
    except (OSError, EOFError, pickle.PickleError, ValueError, IndexError, TypeError):
        pass

    return [
        [random.uniform(-2, 2) for _ in range(5)] + [0]
        for _ in range(POPULATION_SIZE)
    ]

def save_population():
    with open(AI_FILE, "wb") as file:
        pickle.dump(population, file)

def evolve_population():
    global population, ai_index

    population.sort(key=lambda genome: genome[5], reverse=True)
    save_population()

    survivors = population[:max(2, POPULATION_SIZE // 5)]
    population = [genome[:5] + [0] for genome in survivors]

    while len(population) < POPULATION_SIZE:
        first, second = random.sample(survivors, 2)
        child = [
            first[index] if random.random() < 0.5 else second[index]
            for index in range(5)
        ]
        child = [
            gene + random.gauss(0, 0.2)
            if random.random() < 0.25 else gene
            for gene in child
        ]
        population.append(child + [0])

    ai_index = 0
    save_population()

def jump():
    global jump_cooldown

    if game and jump_cooldown == 0:
        flappy.vel = -9
        jump_cooldown = 8

def ai_decide():
    genome = population[ai_index]
    nearest = min(
        (
            pipe for pipe in pipe_group
            if pipe.rect.right >= flappy.rect.left
        ),
        key=lambda pipe: pipe.rect.centerx,
        default=None
    )

    gap_y = nearest.gap_y if nearest is not None else HEIGHT / 2
    distance = (
        nearest.rect.centerx - flappy.rect.centerx
        if nearest is not None
        else WIDTH
    )

    features = (
        flappy.rect.centery / HEIGHT,
        flappy.vel / 8,
        distance / WIDTH,
        (gap_y - flappy.rect.centery) / HEIGHT,
        1
    )

    decision = sum(
        weight * value
        for weight, value in zip(genome[:5], features)
    )

    if decision > 0:
        jump()

def reset_game():
    global score, last_pipe, game, jump_cooldown, ai_start_time

    pipe_group.empty()
    flappy.rect.topleft = (200, HEIGHT / 2)
    flappy.vel = 0
    jump_cooldown = 0
    ai_start_time = pygame.time.get_ticks()
    score = 0
    last_pipe = pygame.time.get_ticks()
    game = True

def reset_ai_bird():
    global ai_index

    survival_time = pygame.time.get_ticks() - ai_start_time
    population[ai_index][5] = score * 1000 + survival_time
    save_population()

    ai_index += 1

    if ai_index >= POPULATION_SIZE:
        evolve_population()

    reset_game()

population = load_population()
ai_index = 0

class Bird(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.frames = frame123
        self.index = 0
        self.image = self.frames[self.index]
        self.counter = 0
        self.rect = self.image.get_rect(topleft=(x, y))
        self.vel = 0

    def update(self):
        global game, high_score, score

        if game:
            self.vel = min(self.vel + 0.5, 8)
            self.rect.y += int(self.vel)

            if self.rect.bottom >= 668:
                self.rect.bottom = 668
                game = False

            if self.rect.top <= 0:
                game = False

            if not game and int(score) > high_score:
                high_score = int(score)

            self.counter += 1

            if self.counter >= 5:
                self.counter = 0
                self.index = (self.index + 1) % 3
                center = self.rect.center
                self.image = self.frames[self.index]
                self.rect = self.image.get_rect(center=center)

class Pipe(pygame.sprite.Sprite):
    def __init__(self, x, y, position):
        super().__init__()
        self.image = pipe_img
        self.rect = self.image.get_rect()
        self.gap_y = y

        if position == 1:
            self.image = pygame.transform.flip(self.image, False, True)
            self.rect.bottomleft = (x, y - 75)
        else:
            self.rect.topleft = (x, y + 75)

        self.passed = False

    def update(self):
        self.rect.x -= 4

        if self.rect.right < 0:
            self.kill()

flappy = Bird(200, HEIGHT / 2)
bird_group = pygame.sprite.GroupSingle(flappy)
pipe_group = pygame.sprite.Group()
last_pipe = pygame.time.get_ticks() - 1500

while running:
    clock.tick(60)

    if jump_cooldown > 0:
        jump_cooldown -= 1

    if AI_ENABLED and game:
        ai_decide()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        elif event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
            if game:
                jump()
            else:
                reset_game()

        elif event.type == pygame.MOUSEBUTTONDOWN and not game:
            if restart_rect.collidepoint(event.pos):
                reset_game()

    screen.blit(bg, (0, 0))

    if game:
        time_now = pygame.time.get_ticks()

        if time_now - last_pipe > 1500:
            pipe_height = random.randint(-150, 150)
            pipe_group.add(
                Pipe(WIDTH, HEIGHT // 2 + pipe_height, -1),
                Pipe(WIDTH, HEIGHT // 2 + pipe_height, 1)
            )
            last_pipe = time_now

        for pipe in pipe_group:
            if not pipe.passed and pipe.rect.right < flappy.rect.left:
                score += 0.5
                pipe.passed = True

        ground_x -= 4

        if ground_x < -600:
            ground_x = 0

        pipe_group.update()
        bird_group.update()

        if pygame.sprite.spritecollide(flappy, pipe_group, False):
            game = False

    pipe_group.draw(screen)
    screen.blit(ground, (ground_x, 668))
    bird_group.draw(screen)

    if game:
        score_img = font_large.render(str(int(score)), True, (255, 255, 255))
        screen.blit(score_img, (WIDTH // 2 - score_img.get_width() // 2, 50))
    elif AI_ENABLED:
        reset_ai_bird()
        continue
    else:
        game_over_img = font_large.render("GAME OVER", True, (230, 50, 50))
        screen.blit(
            game_over_img,
            (WIDTH // 2 - game_over_img.get_width() // 2, HEIGHT // 2 - 140)
        )

        score_text = font.render(f"SCORE: {int(score)}", True, (255, 255, 255))
        screen.blit(
            score_text,
            (WIDTH // 2 - score_text.get_width() // 2, HEIGHT // 2 - 60)
        )

        high_score_text = font.render(
            f"BEST: {high_score}",
            True,
            (255, 215, 0)
        )
        screen.blit(
            high_score_text,
            (WIDTH // 2 - high_score_text.get_width() // 2, HEIGHT // 2 - 10)
        )

        screen.blit(restart, restart_rect)

    pygame.display.flip()

save_population()
pygame.quit()