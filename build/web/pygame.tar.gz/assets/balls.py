import pygame
import random
import math

pygame.init()

WIDTH = 800
HEIGHT = 800

screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()


class Ball:
    def __init__(self, x, y, r, vx, vy, color):
        self.x = x
        self.y = y
        self.r = r
        self.vx = vx
        self.vy = vy
        self.color = color

    def update(self, t):
        self.x += self.vx * t

        u = self.vy
        self.vy += 500 * t
        self.y += (u + self.vy) * 0.5 * t

        if self.x <= self.r:
            self.x = self.r
            self.vx *= -1

        if self.x >= WIDTH - self.r:
            self.x = WIDTH - self.r
            self.vx *= -1

        if self.y >= HEIGHT - self.r:
            self.y = HEIGHT - self.r
            self.vy *= -0.9

        if self.y <= self.r:
            self.y = self.r
            self.vy *= -1

    def draw(self):
        pygame.draw.circle(
            screen,
            self.color,
            (int(self.x), int(self.y)),
            self.r,
        )


balls = []

colors = [
    "red",
    "blue",
    "green",
    "yellow",
    "purple",
    "orange",
    "cyan",
    "white",
]

for i in range(8):
    balls.append(
        Ball(
            random.randint(50, 750),
            random.randint(50, 300),
            20,
            random.randint(-250, 250),
            random.randint(-150, 150),
            colors[i],
        )
    )

running = True

while running:
    t = clock.tick(60) / 1000

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                for ball in balls:
                    ball.vy -= 500

    for ball in balls:
        ball.update(t)

    for i in range(len(balls)):
        for j in range(i + 1, len(balls)):
            b1 = balls[i]
            b2 = balls[j]

            dx = b2.x - b1.x
            dy = b2.y - b1.y

            distance = math.sqrt(dx * dx + dy * dy)

            if distance <= b1.r + b2.r:
                b1.vx, b2.vx = b2.vx, b1.vx
                b1.vy, b2.vy = b2.vy, b1.vy

                overlap = b1.r + b2.r - distance
                if distance != 0:
                    nx = dx / distance
                    ny = dy / distance
                    b1.x -= nx * overlap / 2
                    b1.y -= ny * overlap / 2
                    b2.x += nx * overlap / 2
                    b2.y += ny * overlap / 2

    screen.fill("#00E5FF")

    for ball in balls:
        ball.draw()

    pygame.display.flip()

pygame.quit()